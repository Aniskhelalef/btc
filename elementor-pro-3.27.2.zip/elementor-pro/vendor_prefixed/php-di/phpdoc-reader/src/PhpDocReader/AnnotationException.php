<?php

declare (strict_types=1);
namespace ElementorProDeps\PhpDocReader;

/**
 * We stumbled upon an invalid class/property/method annotation.
 */
class AnnotationException extends \Exception
{
}
